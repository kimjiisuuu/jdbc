select * from member_tbl_02 mt;
select * from money_tbl_02 ms;

insert into MEMBER_TBL_02 mt values ('100007','김지수','010-2184-7094','경기도 시흥시 은행동','to_date('2000-09-08','yyyy-dd-mm'),'A','55');