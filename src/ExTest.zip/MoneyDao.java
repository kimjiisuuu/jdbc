package ExTest;

public class MoneyDao {

}
