package ExTest;

import java.sql.Date;

public class MoneyDto {
	private String custno;
	private String salenol;
	private int pcost;
	private int amount;
	private int price;
	private String pcode;
	private Date sdate;
	
	public String getCustno() {
		return custno;
	}
	public String getSalenol() {
		return salenol;
	}
	public int getPcost() {
		return pcost;
	}
	public int getAmount() {
		return amount;
	}
	public int getPrice() {
		return price;
	}
	public String getPcode() {
		return pcode;
	}
	public Date getSdate() {
		return sdate;
	}
	
}
