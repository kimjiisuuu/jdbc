package ExTest;

import java.lang.reflect.Member;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import koreait.jdbc.day2.OracleUtilty;


public class MemberDao {
	
	public int insertInquary(List<MembertDto> member) throws SQLException {
		 Connection connection = OracleUtilty.getConnection();
	      String sql = "insert into j_member values(MemberDto_seq.nextval,?,?,?,?,?,?,?)";
	      PreparedStatement ps = connection.prepareStatement(sql);
	     
	      int count = 0;
	      try {
	          connection.setAutoCommit(false);
	          ps = connection.prepareStatement(sql);
	          for(MembertDto m : member) {
	             ps.setString(1, m.getCustname());
	             ps.setInt(2, m.getPhone());
	             ps.setString(3, m.getAddress());
	             ps.setDate(4, m.getJoindate());
	             ps.setString(5, m.getGrade());
	             ps.setString(6, m.getCity());
	             count += ps.executeUpdate();
	          }
	          connection.commit();
	       } catch (SQLException e) {
	          System.out.println("" + e.getMessage());
	          try {
	             connection.rollback();
	          } catch(SQLException e1) {
	          }
	       }
	       return count;
	      
	   }
	      public List<MemberDto> selectAll() throws SQLException {
	            Connection conn = OracleUtilty.getConnection();
	            String sql = "select * from j_member";
	            PreparedStatement ps = conn.prepareStatement(sql);
	            List<MemberDto> result = new ArrayList<>();
	            
	            
	            ResultSet rs = ps.executeQuery();
	            if(rs.next()) {
	            	String custno = rs.getString(1);
	               String custname = rs.getString(2);
	               String phone = rs.getString(3);
	               String address = rs.getString(4);
	               Date joindate = rs.getDate(5);
	               String grade = rs.getString(6);
	               String city = rs.getString(7);
	              result.add(new MemberDto(custno, custname, phone, address, joindate, grade, city));
	            }
	            return result;
	         }
	         
	         public int update(Member md) throws SQLException {
	            Connection conn = OracleUtilty.getConnection();
	            String sql = "update j_member set custname = ?,phone = ?,address =?,city =?";
	            PreparedStatement ps = conn.prepareStatement(sql);
	            ps.setString(1, md.getName());
	            ps.setInt(2, md.getModifiers());
	            ps.setString(3, md.get);
	            ps.setString(4, md.getCity());
	            int result = ps.executeUpdate();
	            
	            ps.close();
	            conn.close();
	            return result;
	         }}

