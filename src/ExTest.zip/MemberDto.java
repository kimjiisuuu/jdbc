package ExTest;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;



@Getter
@ToString
@AllArgsConstructor
@Builder
public class MemberDto {

	private String custon;
	private String custname;
	private String  phone;
	private String address;
	private Date joindate;
	private String grade;
	private String city;
	
	
	
	public MemberDto(String custon, String custname, String phone, String address, Date joindate, String grade,
			String city) {
		super();
		this.custon = custon;
		this.custname = custname;
		this.phone = phone;
		this.address = address;
		this.joindate = joindate;
		this.grade = grade;
		this.city = city;
	}
	public String getCuston() {
		return custon;
	}
	public void setCuston(String custon) {
		this.custon = custon;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Date getJoindate() {
		return joindate;
	}
	public void setJoindate(Date joindate) {
		this.joindate = joindate;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
}
